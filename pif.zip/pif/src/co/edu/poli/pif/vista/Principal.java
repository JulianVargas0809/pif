package co.edu.poli.pif.vista;
/**
 * 
 * 
 */


import java.util.*;
import co.edu.poli.pif.modelo.*;
import co.edu.poli.pif.servicios.*;

public class Principal {

	public static void main(String[] args) {

		// UnidadDeMedida unidad2 = new UnidadDeMedidaVolumen(null, null, null, 0, null,
		// false, null, null, 0, 0, 0, null);

		// Agregacion Fuerte
		EquipoLaboratorio equipo = new EquipoLaboratorio("foneba", "luiser", "asdb214");

		RegistroDeMedida regMed = new RegistroDeMedida("2024-10-20", 0, null, equipo);

		//UnidadDeMedida unidad1 = new UnidadDeMedidaMasa("Kilogramos", "kg", "Masa", 1.0, "Unidad de masa estándar",
		//		true, "kg", "ID001", null, "Informe de peso", regMed, "litro");
		
		UnidadDeMedida unidad1 = new UnidadDeMedidaMasa("Kilogramos", "kg", "masa", 1.0, "Unidad masa estandar", true, "kg", "ID001", null, regMed, "litro");
		
		// Agregcion debil
		Laboratorio lab = new Laboratorio("Laboratorio Central", "Av. Principal", "123454", "n equipos");

		unidad1.setLaboratorio(lab);

		// polimorfismo

		UnidadDeMedida[] Medicion = new UnidadDeMedida[5];
		//UnidadDeMedidaMasa masa1 = new UnidadDeMedidaMasa("Kilogramo", "kg", "Masa", 0, "Unidad básica de masa", true,
		//		null, "UM001", lab, "Informe sobre kilogramo", regMed, "Kilogramo");
		UnidadDeMedidaMasa masa1 = new UnidadDeMedidaMasa(null, null, null, 0, null, false, null, null, null, regMed, null);
		//UnidadDeMedidaMasa masa2 = new UnidadDeMedidaMasa("Gramo", "g", "Masa", 0.001, "Unidad más pequeña de masa",
		//		false, "Kilogramo", "UM002", lab, "Informe sobre gramo", regMed, "Kilogramo");
		UnidadDeMedidaMasa masa2 = new UnidadDeMedidaMasa(null, null, null, 0, null, false, null, null, null, regMed, null);
		//UnidadDeMedidaVolumen volumen1 = new UnidadDeMedidaVolumen("Fontibon", "Ml", "tipo 2", 15.89, "Descripcion",
		//		false, "base3", "asfd123", lab, null, regMed, 0, 0, 0, null);
		UnidadDeMedidaVolumen volumen1 = new UnidadDeMedidaVolumen(null, null, null, 0, null, false, null, null, null, regMed, 0, 0, 0, null);

		Medicion[0] = unidad1;
		Medicion[1] = masa1;
		Medicion[2] = masa2;
		Medicion[3] = volumen1;

		for (int i = 0; i < Medicion.length; i++) {
			if (Medicion[i] != null) {
				System.out.println(Medicion[i].convertirDesdeUnidadBase());
			}
		}

		Mililitro chiqui = new Mililitro("Mililitro", "mL", "Volumen", 0.001, "Unidad de medida de volumen", false,
				"Litro", "UM003", "Informe sobre mililitros", regMed, 100.0, 101.325, 20.0, "Litro", 0.001, 1,
				"Mediciones de líquidos", 100.0);

		UsuarioLaboratorio uL = new UsuarioLaboratorio("Juan", "Pérez", "juan.perez@example.com", "Investigador");

		System.out.println(uL.generarReporteActividad(chiqui));

		// operaciones Crud
		implementacionOperacion op = new implementacionOperacion();

		System.out.println(op.create(masa1));
		System.out.println(op.create(volumen1));
		System.out.println(op.create(masa2));

		System.out.println(Arrays.toString(op.readAll()));

		volumen1.setTipo("tipo 2");
		volumen1.setAbreviatura("landcruiser");

		op.update("dac15e", volumen1);

		System.out.println(Arrays.toString(op.readAll()));

		op.delete("zjy82f");

		System.out.println(Arrays.toString(op.readAll()));

		// op.serializar(op.readAll(), "", "actividad8,2.bin");

		// System.out.println(Arrays.toString(op.deserializar("", "actividad8,2.bin")));

		Scanner sc = new Scanner(System.in);

		boolean salir = false;

		while (!salir) {
			System.out.println("\n---- Menú de Operaciones ----");
			System.out.println("1. Crear");
			System.out.println("2. Leer");
			System.out.println("3. Actualizar");
			System.out.println("4. Eliminar");
			System.out.println("5. Serializar");
			System.out.println("6. Deserializar");
			System.out.println("7. Salir");
			System.out.print("Elige una opción: ");
			int opcion = sc.nextInt();
			sc.nextLine(); // Limpiar buffer

			switch (opcion) {
			case 1: // Crear
				System.out.println("Creando una nueva Unidad de Medida...");
				UnidadDeMedidaMasa nuevaMasa = new UnidadDeMedidaMasa("Gramo", "g", "Masa", 0.001, "Unidad de masa",
						false, "Kilogramo", "UM002", null, null, "Kilogramo");
				System.out.println(op.create(nuevaMasa));
				break;

			case 2: // Leer
				System.out.println("Leyendo todas las unidades de medida:");
				System.out.println(Arrays.toString(op.readAll()));
				break;

			case 3: // Actualizar
				System.out.println("Actualizando una Unidad de Medida...");
				System.out.println("Introduce el ID de la unidad que quieres actualizar: ");
				String id = sc.nextLine();
				UnidadDeMedidaVolumen nuevaVol = new UnidadDeMedidaVolumen("Fontibon", "mL", "Volumen", 1.0,
						"Actualizado", false, "Litro", id, null, null, 0, 0, 0, null);
				op.update(id, nuevaVol);
				System.out.println("Unidad actualizada.");
				break;

			case 4: // Eliminar
				System.out.println("Introduce el ID de la unidad a eliminar: ");
				String idEliminar = sc.nextLine();
				op.delete(idEliminar);
				System.out.println("Unidad eliminada.");
				break;

			case 5: // Serializar
				System.out.println("Serializando...");
				op.serializar(op.readAll(), "", "actividad8,2.bin");
				System.out.println("Datos serializados.");
				break;

			case 6: // Deserializar
				System.out.println("Deserializando...");
				UnidadDeMedida[] deserializados = op.deserializar("", "actividad8,2.bin");
				System.out.println("Datos deserializados:");
				System.out.println(Arrays.toString(deserializados));
				break;

			case 7: // Salir
				salir = true;
				System.out.println("Saliendo del sistema...");
				break;

			default:
				System.out.println("Opción no válida. Intenta de nuevo.");
			}
		}
		sc.close();

	}

}