package co.edu.poli.pif.modelo;

import java.io.Serializable;

public class Laboratorio implements Serializable{
	
	private String nombre;
	
	private String direccion;
	
	private String codigo;
	
	private String capacidadMaximaEquipos;

	public Laboratorio(String nombre, String direccion, String codigo, String capacidadMaximaEquipos) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		this.codigo = codigo;
		this.capacidadMaximaEquipos = capacidadMaximaEquipos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCapacidadMaximaEquipos() {
		return capacidadMaximaEquipos;
	}

	public void setCapacidadMaximaEquipos(String capacidadMaximaEquipos) {
		this.capacidadMaximaEquipos = capacidadMaximaEquipos;
	}

	@Override
	public String toString() {
		return "Laboratorio [nombre=" + nombre + ", direccion=" + direccion + ", codigo=" + codigo
				+ ", capacidadMaximaEquipos=" + capacidadMaximaEquipos + ", toString()=" + super.toString() + "]";
	}
	
}
