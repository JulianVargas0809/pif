package co.edu.poli.pif.modelo;

import java.io.Serializable;

public class UnidadDeMedidaMasa extends UnidadDeMedida implements Serializable {

	String unidadEstandar;

	public boolean esEquivalente() {
		return false;
	}


	public UnidadDeMedidaMasa(String nombre, String abreviatura, String tipo, double factorConversion,
			String descripcion, boolean esUnidadBase, String unidadBase, String id, String informe,
			RegistroDeMedida registroDeMedida, String unidadEstandar) {
		super(nombre, abreviatura, tipo, factorConversion, descripcion, esUnidadBase, unidadBase, id, informe,
				registroDeMedida);
		this.unidadEstandar = unidadEstandar;
	}


	public String getUnidadEstandar() {
		return unidadEstandar;
	}

	public void setUnidadEstandar(String unidadEstandar) {
		this.unidadEstandar = unidadEstandar;
	}

	@Override
	public String toString() {
		return "UnidadDeMedidaMasa [unidadEstandar=" + unidadEstandar + ", toString()=" + super.toString() + "]";
	}

}