package co.edu.poli.pif.modelo;

import java.io.Serializable;

public class RegistroDeMedida implements Serializable {

	private String fecha;

	private double valorMedida;

	private UnidadDeMedida UnidadDeMedida;

	private EquipoLaboratorio equipo;

	public RegistroDeMedida(String fecha, double valorMedida, co.edu.poli.pif.modelo.UnidadDeMedida unidadDeMedida,
			EquipoLaboratorio equipo) {
		super();
		this.fecha = fecha;
		this.valorMedida = valorMedida;
		UnidadDeMedida = unidadDeMedida;
		this.equipo = equipo;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public double getValorMedida() {
		return valorMedida;
	}

	public void setValorMedida(double valorMedida) {
		this.valorMedida = valorMedida;
	}

	public UnidadDeMedida getUnidadDeMedida() {
		return UnidadDeMedida;
	}

	public void setUnidadDeMedida(UnidadDeMedida unidadDeMedida) {
		UnidadDeMedida = unidadDeMedida;
	}

	public EquipoLaboratorio getEquipo() {
		return equipo;
	}

	public void setEquipo(EquipoLaboratorio equipo) {
		this.equipo = equipo;
	}

	@Override
	public String toString() {
		return "RegistroDeMedida [fecha=" + fecha + ", valorMedida=" + valorMedida + ", UnidadDeMedida="
				+ UnidadDeMedida + ", equipo=" + equipo + ", toString()=" + super.toString() + "]";
	}



}