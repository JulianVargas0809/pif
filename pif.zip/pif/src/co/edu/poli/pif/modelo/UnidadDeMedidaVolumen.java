package co.edu.poli.pif.modelo;

import java.io.Serializable;

public class UnidadDeMedidaVolumen extends UnidadDeMedida implements Serializable{

	private double capacidadMaxima;

	private double presionReferencia;

	private double temperaturaReferencia;

	private String unidadEstandar;

	public boolean esEquivalente() {
		return false;
	}

	public UnidadDeMedidaVolumen(String nombre, String abreviatura, String tipo, double factorConversion,
			String descripcion, boolean esUnidadBase, String unidadBase, String id, String informe,
			RegistroDeMedida registroDeMedida, double capacidadMaxima, double presionReferencia,
			double temperaturaReferencia, String unidadEstandar) {
		super(nombre, abreviatura, tipo, factorConversion, descripcion, esUnidadBase, unidadBase, id, informe,
				registroDeMedida);
		this.capacidadMaxima = capacidadMaxima;
		this.presionReferencia = presionReferencia;
		this.temperaturaReferencia = temperaturaReferencia;
		this.unidadEstandar = unidadEstandar;
	}


	public double getCapacidadMaxima() {
		return capacidadMaxima;
	}

	public void setCapacidadMaxima(double capacidadMaxima) {
		this.capacidadMaxima = capacidadMaxima;
	}

	public double getPresionReferencia() {
		return presionReferencia;
	}

	public void setPresionReferencia(double presionReferencia) {
		this.presionReferencia = presionReferencia;
	}

	public double getTemperaturaReferencia() {
		return temperaturaReferencia;
	}

	public void setTemperaturaReferencia(double temperaturaReferencia) {
		this.temperaturaReferencia = temperaturaReferencia;
	}

	public String getUnidadEstandar() {
		return unidadEstandar;
	}

	public void setUnidadEstandar(String unidadEstandar) {
		this.unidadEstandar = unidadEstandar;
	}

	@Override
	public String toString() {
		return "UnidadDeMedidaVolumen [capacidadMaxima=" + capacidadMaxima + ", presionReferencia=" + presionReferencia
				+ ", temperaturaReferencia=" + temperaturaReferencia + ", unidadEstandar=" + unidadEstandar
				+ ", toString()=" + super.toString() + "]";
	}

}