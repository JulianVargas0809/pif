package co.edu.poli.pif.modelo;

import java.io.Serializable;

public class UsuarioLaboratorio implements Serializable {

    private String nombre;

    private String apellido;

    private String correo;

    private String cargo;

	public UsuarioLaboratorio(String nombre, String apellido, String correo, String cargo) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.correo = correo;
		this.cargo = cargo;
	}
	
	public String generarReporteActividad(UnidadDeMedida informe) {
        return informe.getClass().getSimpleName();
    }

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	@Override
	public String toString() {
		return "UsuarioLaboratorio [nombre=" + nombre + ", apellido=" + apellido + ", correo=" + correo + ", cargo="
				+ cargo + ", toString()=" + super.toString() + "]";
	}



}