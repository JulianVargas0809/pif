package co.edu.poli.pif.modelo;

public abstract class UnidadDeMedida {

    private String nombre;

    private String abreviatura;

    private String tipo;

    private double factorConversion;

    private String descripcion;

    private boolean esUnidadBase;

    private String unidadBase;

    private String id;
    
    private Laboratorio laboratorio;
    
    private String informe;
    
    private RegistroDeMedida registroDeMedida; 

    public double convertirAUnidadBase(double valor) {
        return 0.0d;
    }

    public double convertirAUnidadBase(double valor, int precision) {
        return 0.0d;
    }

    public double convertirDesdeUnidadBase() {
        return 0.0d;
    }

    public abstract boolean esEquivalente();

	public UnidadDeMedida(String nombre, String abreviatura, String tipo, double factorConversion, String descripcion,
			boolean esUnidadBase, String unidadBase, String id, String informe, RegistroDeMedida registroDeMedida) {
		super();
		this.nombre = nombre;
		this.abreviatura = abreviatura;
		this.tipo = tipo;
		this.factorConversion = factorConversion;
		this.descripcion = descripcion;
		this.esUnidadBase = esUnidadBase;
		this.unidadBase = unidadBase;
		this.id = id;
		this.informe = informe;
		this.registroDeMedida = registroDeMedida;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getAbreviatura() {
		return abreviatura;
	}

	public void setAbreviatura(String abreviatura) {
		this.abreviatura = abreviatura;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getFactorConversion() {
		return factorConversion;
	}

	public void setFactorConversion(double factorConversion) {
		this.factorConversion = factorConversion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public boolean isEsUnidadBase() {
		return esUnidadBase;
	}

	public void setEsUnidadBase(boolean esUnidadBase) {
		this.esUnidadBase = esUnidadBase;
	}

	public String getUnidadBase() {
		return unidadBase;
	}

	public void setUnidadBase(String unidadBase) {
		this.unidadBase = unidadBase;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Laboratorio getLaboratorio() {
		return laboratorio;
	}

	public void setLaboratorio(Laboratorio laboratorio) {
		this.laboratorio = laboratorio;
	}

	public String getInforme() {
		return informe;
	}

	public void setInforme(String informe) {
		this.informe = informe;
	}

	public RegistroDeMedida getRegistroDeMedida() {
		return registroDeMedida;
	}

	public void setRegistroDeMedida(RegistroDeMedida registroDeMedida) {
		this.registroDeMedida = registroDeMedida;
	}

	@Override
	public String toString() {
		return "UnidadDeMedida [nombre=" + nombre + ", abreviatura=" + abreviatura + ", tipo=" + tipo
				+ ", factorConversion=" + factorConversion + ", descripcion=" + descripcion + ", esUnidadBase="
				+ esUnidadBase + ", unidadBase=" + unidadBase + ", id=" + id + ", informe=" + informe
				+ ", registroDeMedida=" + registroDeMedida + ", toString()=" + super.toString() + "]";
	}

}