package co.edu.poli.pif.servicios;

import java.io.*;
import co.edu.poli.pif.modelo.UnidadDeMedida;

public class implementacionOperacion implements Operacion {

	private UnidadDeMedida[] unidadesDeMedidas;

	public implementacionOperacion() {
		unidadesDeMedidas = new UnidadDeMedida[1];
	}

	public String create(UnidadDeMedida UM) {
		for (int i = 0; i < unidadesDeMedidas.length; i++) {
			if (unidadesDeMedidas[i] == null) {
				unidadesDeMedidas[i] = UM;
				return "se ha agregado exitosamente";
			}
		}
		// metodo para un arreglo infinito
		UnidadDeMedida[] vehiAux = new UnidadDeMedida[unidadesDeMedidas.length * 2];
		System.arraycopy(unidadesDeMedidas, 0, vehiAux, 0, unidadesDeMedidas.length);
		vehiAux[unidadesDeMedidas.length] = UM;
		unidadesDeMedidas = vehiAux;

		return "se ha agregado exitosamente.";
	}

	public UnidadDeMedida[] readAll() {
		return unidadesDeMedidas;
	}

	public UnidadDeMedida read(String id) {
		for (int i = 0; i < unidadesDeMedidas.length; i++) {
			if (unidadesDeMedidas[i] != null && unidadesDeMedidas[i].getId().equals(id)) {
				return unidadesDeMedidas[i];
			}
		}
		return null;
	}

	public String update(String id, UnidadDeMedida JK) {
		for (int i = 0; i < unidadesDeMedidas.length; i++) {
			if (unidadesDeMedidas[i] != null && unidadesDeMedidas[i].getId().equals(id)) {
				unidadesDeMedidas[i] = JK;
				return "se ha modificado";
			}
		}
		return "no se ha modificado por que no se encuentra el objeto";
	}

	public UnidadDeMedida delete(String id) {
		for (int i = 0; i < unidadesDeMedidas.length; i++) {
			if (unidadesDeMedidas[i] != null && unidadesDeMedidas[i].getId().equals(id)) {
				UnidadDeMedida temp = unidadesDeMedidas[i];

				unidadesDeMedidas[i] = null;

				return temp;
			}
		}
		return null;
	}

	public String serializar(UnidadDeMedida[] unidadesDeMedidas, String path, String name) {
		try {
			FileOutputStream fos = new FileOutputStream(path + name);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(unidadesDeMedidas);
			oos.close();
			fos.close();
			return "File create!!";
		} catch (IOException ioe) {
			return "Error file " + ioe.getMessage();
		}
	}

	public UnidadDeMedida[] deserializar(String path, String name) {
		UnidadDeMedida[] a = null;
		try {
			FileInputStream fis = new FileInputStream(path + name);
			ObjectInputStream ois = new ObjectInputStream(fis);
			a = (UnidadDeMedida[]) ois.readObject();
			ois.close();
			fis.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
		}
		return a;
	}

}