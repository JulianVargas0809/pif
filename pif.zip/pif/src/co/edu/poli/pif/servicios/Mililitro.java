package co.edu.poli.pif.servicios;

import java.io.Serializable;

import co.edu.poli.pif.modelo.*;

public class Mililitro extends UnidadDeMedidaVolumen implements Serializable {

	public double equivalenciEnLitros;

	public int precisionMedida;

	public String usoRecomendado;

	public double capcacidadMaximaEnSistema;

	public double convertirALitros(double volumenEnMililitros) {
		return 0.0d;
	}

	public boolean validarPrecision(double volumen) {
		return false;
	}


	public Mililitro(String nombre, String abreviatura, String tipo, double factorConversion, String descripcion,
			boolean esUnidadBase, String unidadBase, String id, String informe, RegistroDeMedida registroDeMedida,
			double capacidadMaxima, double presionReferencia, double temperaturaReferencia, String unidadEstandar,
			double equivalenciEnLitros, int precisionMedida, String usoRecomendado, double capcacidadMaximaEnSistema) {
		super(nombre, abreviatura, tipo, factorConversion, descripcion, esUnidadBase, unidadBase, id, informe,
				registroDeMedida, capacidadMaxima, presionReferencia, temperaturaReferencia, unidadEstandar);
		this.equivalenciEnLitros = equivalenciEnLitros;
		this.precisionMedida = precisionMedida;
		this.usoRecomendado = usoRecomendado;
		this.capcacidadMaximaEnSistema = capcacidadMaximaEnSistema;
	}

	public double getEquivalenciEnLitros() {
		return equivalenciEnLitros;
	}

	public void setEquivalenciEnLitros(double equivalenciEnLitros) {
		this.equivalenciEnLitros = equivalenciEnLitros;
	}

	public int getPrecisionMedida() {
		return precisionMedida;
	}

	public void setPrecisionMedida(int precisionMedida) {
		this.precisionMedida = precisionMedida;
	}

	public String getUsoRecomendado() {
		return usoRecomendado;
	}

	public void setUsoRecomendado(String usoRecomendado) {
		this.usoRecomendado = usoRecomendado;
	}

	public double getCapcacidadMaximaEnSistema() {
		return capcacidadMaximaEnSistema;
	}

	public void setCapcacidadMaximaEnSistema(double capcacidadMaximaEnSistema) {
		this.capcacidadMaximaEnSistema = capcacidadMaximaEnSistema;
	}

	@Override
	public String toString() {
		return "Mililitro [equivalenciEnLitros=" + equivalenciEnLitros + ", precisionMedida=" + precisionMedida
				+ ", usoRecomendado=" + usoRecomendado + ", capcacidadMaximaEnSistema=" + capcacidadMaximaEnSistema
				+ ", toString()=" + super.toString() + "]";
	}

	@Override
	public boolean esEquivalente() {
		return false;
	}

}