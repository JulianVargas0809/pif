package co.edu.poli.pif.servicios;

import co.edu.poli.pif.modelo.UnidadDeMedida;

public interface Operacion {

    public String create(UnidadDeMedida UM);

    public UnidadDeMedida [ ] readAll();

    public UnidadDeMedida read(String id);

    public String update(String id, UnidadDeMedida JK);

    public UnidadDeMedida delete(String id);

    public String serializar(UnidadDeMedida [ ] unidadesDeMedidas, String path, String name);

    public UnidadDeMedida [ ] deserializar(String path, String name);

}